import React, { useState, useEffect } from 'react';
import { Heart, Pill, Phone, MessageCircle, Sun, Cloud, CloudRain, Calendar, Activity, Settings } from 'lucide-react';

interface HealthMetrics {
  mood: number;
  energy: number;
  sleep: number;
  lastCheckIn: string;
}

interface Medication {
  id: string;
  name: string;
  time: string;
  taken: boolean;
}

const Dashboard: React.FC = () => {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [healthMetrics, setHealthMetrics] = useState<HealthMetrics>({
    mood: 4,
    energy: 3,
    sleep: 4,
    lastCheckIn: 'Today, 9:00 AM'
  });
  
  const [medications] = useState<Medication[]>([
    { id: '1', name: 'Morning Vitamins', time: '8:00 AM', taken: false },
    { id: '2', name: 'Heart Medicine', time: '12:00 PM', taken: true },
    { id: '3', name: 'Evening Tablets', time: '6:00 PM', taken: false }
  ]);

  const [userName] = useState('Margaret');

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 60000);
    return () => clearInterval(timer);
  }, []);

  const getGreeting = () => {
    const hour = currentTime.getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    return 'Good evening';
  };

  const getWeatherIcon = () => {
    const hour = currentTime.getHours();
    if (hour >= 6 && hour < 18) return <Sun className="h-8 w-8 text-yellow-500" />;
    return <Cloud className="h-8 w-8 text-gray-400" />;
  };

  const upcomingMeds = medications.filter(med => !med.taken);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="bg-blue-600 p-2 rounded-lg">
                <Heart className="h-6 w-6 text-white" />
              </div>
              <h1 className="text-2xl font-bold text-gray-900">EchoCare</h1>
            </div>
            <button className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors">
              <Settings className="h-6 w-6" />
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-8">
        {/* Greeting Section */}
        <div className="bg-white rounded-2xl shadow-lg p-8 mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-2">
                {getGreeting()}, {userName}!
              </h2>
              <p className="text-lg text-gray-600">
                {currentTime.toLocaleDateString('en-US', { 
                  weekday: 'long', 
                  year: 'numeric', 
                  month: 'long', 
                  day: 'numeric' 
                })}
              </p>
              <p className="text-2xl font-semibold text-gray-800 mt-2">
                {currentTime.toLocaleTimeString('en-US', { 
                  hour: 'numeric', 
                  minute: '2-digit',
                  hour12: true 
                })}
              </p>
            </div>
            <div className="flex items-center space-x-4">
              {getWeatherIcon()}
              <div className="text-right">
                <p className="text-2xl font-bold text-gray-900">72°F</p>
                <p className="text-sm text-gray-600">Partly Cloudy</p>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Actions Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {/* AI Companion */}
          <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl p-6 text-white cursor-pointer hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
            <div className="flex items-center justify-between mb-4">
              <MessageCircle className="h-8 w-8" />
              <div className="bg-white bg-opacity-20 px-3 py-1 rounded-full text-sm">
                Available
              </div>
            </div>
            <h3 className="text-xl font-bold mb-2">Chat with Echo</h3>
            <p className="text-blue-100">Your AI companion is ready to chat</p>
          </div>

          {/* Health Check */}
          <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-2xl p-6 text-white cursor-pointer hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
            <div className="flex items-center justify-between mb-4">
              <Heart className="h-8 w-8" />
              <div className="bg-white bg-opacity-20 px-3 py-1 rounded-full text-sm">
                {healthMetrics.lastCheckIn.includes('Today') ? 'Complete' : 'Due'}
              </div>
            </div>
            <h3 className="text-xl font-bold mb-2">Health Check</h3>
            <p className="text-green-100">Daily wellness check-in</p>
          </div>

          {/* Medications */}
          <div className="bg-gradient-to-br from-orange-500 to-orange-600 rounded-2xl p-6 text-white cursor-pointer hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
            <div className="flex items-center justify-between mb-4">
              <Pill className="h-8 w-8" />
              <div className="bg-white bg-opacity-20 px-3 py-1 rounded-full text-sm">
                {upcomingMeds.length} due
              </div>
            </div>
            <h3 className="text-xl font-bold mb-2">Medications</h3>
            <p className="text-orange-100">Manage your daily medications</p>
          </div>

          {/* Emergency */}
          <div className="bg-gradient-to-br from-red-500 to-red-600 rounded-2xl p-6 text-white cursor-pointer hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
            <div className="flex items-center justify-between mb-4">
              <Phone className="h-8 w-8" />
              <div className="bg-white bg-opacity-20 px-3 py-1 rounded-full text-sm">
                Ready
              </div>
            </div>
            <h3 className="text-xl font-bold mb-2">Emergency</h3>
            <p className="text-red-100">Quick access to help</p>
          </div>
        </div>

        {/* Today's Overview */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Health Summary */}
          <div className="bg-white rounded-2xl shadow-lg p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-gray-900">Health Summary</h3>
              <Activity className="h-6 w-6 text-gray-400" />
            </div>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-gray-600">Mood</span>
                <div className="flex space-x-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <div
                      key={star}
                      className={`w-3 h-3 rounded-full ${
                        star <= healthMetrics.mood ? 'bg-yellow-400' : 'bg-gray-200'
                      }`}
                    />
                  ))}
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-gray-600">Energy Level</span>
                <div className="flex space-x-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <div
                      key={star}
                      className={`w-3 h-3 rounded-full ${
                        star <= healthMetrics.energy ? 'bg-green-400' : 'bg-gray-200'
                      }`}
                    />
                  ))}
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-gray-600">Sleep Quality</span>
                <div className="flex space-x-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <div
                      key={star}
                      className={`w-3 h-3 rounded-full ${
                        star <= healthMetrics.sleep ? 'bg-blue-400' : 'bg-gray-200'
                      }`}
                    />
                  ))}
                </div>
              </div>
            </div>
            
            <div className="mt-6 p-4 bg-green-50 rounded-lg">
              <p className="text-sm text-green-800">
                <strong>Last check-in:</strong> {healthMetrics.lastCheckIn}
              </p>
            </div>
          </div>

          {/* Upcoming Medications */}
          <div className="bg-white rounded-2xl shadow-lg p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-gray-900">Today's Medications</h3>
              <Pill className="h-6 w-6 text-gray-400" />
            </div>
            
            <div className="space-y-3">
              {medications.map((med) => (
                <div
                  key={med.id}
                  className={`flex items-center justify-between p-4 rounded-lg border-2 transition-colors ${
                    med.taken
                      ? 'border-green-200 bg-green-50'
                      : 'border-orange-200 bg-orange-50'
                  }`}
                >
                  <div>
                    <h4 className="font-semibold text-gray-900">{med.name}</h4>
                    <p className="text-sm text-gray-600">{med.time}</p>
                  </div>
                  <div
                    className={`px-3 py-1 rounded-full text-sm font-medium ${
                      med.taken
                        ? 'bg-green-100 text-green-800'
                        : 'bg-orange-100 text-orange-800'
                    }`}
                  >
                    {med.taken ? 'Taken' : 'Due'}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Today's Suggestions */}
        <div className="mt-8 bg-white rounded-2xl shadow-lg p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold text-gray-900">Today's Suggestions</h3>
            <Calendar className="h-6 w-6 text-gray-400" />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 bg-blue-50 rounded-lg">
              <h4 className="font-semibold text-blue-900 mb-2">Morning Walk</h4>
              <p className="text-sm text-blue-700">Perfect weather for a 15-minute walk in the garden</p>
            </div>
            
            <div className="p-4 bg-purple-50 rounded-lg">
              <h4 className="font-semibold text-purple-900 mb-2">Call Sarah</h4>
              <p className="text-sm text-purple-700">Your daughter called yesterday - she'd love to hear from you</p>
            </div>
            
            <div className="p-4 bg-green-50 rounded-lg">
              <h4 className="font-semibold text-green-900 mb-2">Hydration Reminder</h4>
              <p className="text-sm text-green-700">Remember to drink water throughout the day</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;