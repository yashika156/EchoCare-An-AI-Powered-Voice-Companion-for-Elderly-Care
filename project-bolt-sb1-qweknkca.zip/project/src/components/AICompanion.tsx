import React, { useState, useRef, useEffect } from 'react';
import { MessageCircle, Send, Heart, Smile, ArrowLeft, Mic, Volume2 } from 'lucide-react';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'ai';
  timestamp: Date;
  mood?: 'happy' | 'caring' | 'encouraging' | 'informative';
}

interface AICompanionProps {
  onBack: () => void;
}

const AICompanion: React.FC<AICompanionProps> = ({ onBack }) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: "Hello Margaret! It's wonderful to see you today. How are you feeling this morning?",
      sender: 'ai',
      timestamp: new Date(),
      mood: 'caring'
    }
  ]);
  
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const aiResponses = [
    {
      triggers: ['hello', 'hi', 'hey', 'good morning', 'good afternoon', 'good evening'],
      responses: [
        "Hello there! It's so nice to chat with you. How has your day been so far?",
        "Hi Margaret! I'm always happy to see you. What would you like to talk about today?",
        "Good to see you! I hope you're having a lovely day. How are you feeling?"
      ],
      mood: 'happy' as const
    },
    {
      triggers: ['tired', 'sleepy', 'exhausted', 'fatigue'],
      responses: [
        "I understand you're feeling tired. Have you been able to get enough rest lately? Sometimes a short walk or some gentle stretching can help boost energy.",
        "Feeling tired is completely normal. Make sure you're staying hydrated and consider taking a short rest. Your wellbeing is important.",
        "It sounds like you need some self-care time. Would you like some suggestions for gentle activities that might help you feel more energized?"
      ],
      mood: 'caring' as const
    },
    {
      triggers: ['sad', 'lonely', 'depressed', 'down', 'blue'],
      responses: [
        "I'm sorry you're feeling this way. Remember that it's okay to have difficult days. You're not alone - I'm here with you, and your family cares about you deeply.",
        "Your feelings are valid, and it's important to acknowledge them. Sometimes talking about what's bothering you can help. I'm here to listen.",
        "I can sense you're going through a tough time. Would you like to talk about what's on your mind? Sometimes sharing can lighten the load."
      ],
      mood: 'caring' as const
    },
    {
      triggers: ['happy', 'good', 'great', 'wonderful', 'excellent', 'fantastic'],
      responses: [
        "That's wonderful to hear! Your positive energy is contagious. What's making you feel so good today?",
        "I'm so glad you're feeling great! It makes my day to hear you're doing well. Keep that beautiful smile!",
        "Your happiness brings me joy too! Would you like to share what's been going well in your life?"
      ],
      mood: 'happy' as const
    },
    {
      triggers: ['medicine', 'medication', 'pills', 'doctor', 'health'],
      responses: [
        "Health is so important! I see you've been keeping up with your medications. How are you feeling about your current health routine?",
        "It's great that you're staying on top of your health. Remember, if you have any concerns, your doctor is always the best person to ask.",
        "Taking care of your health shows how much you value yourself. That's something to be proud of!"
      ],
      mood: 'encouraging' as const
    },
    {
      triggers: ['family', 'children', 'grandchildren', 'daughter', 'son'],
      responses: [
        "Family is such a blessing! Tell me about your family - I'd love to hear about them.",
        "Your family sounds wonderful. I'm sure they're very proud of you. When did you last speak with them?",
        "It's clear how much your family means to you. Those connections are so precious and important for our wellbeing."
      ],
      mood: 'caring' as const
    },
    {
      triggers: ['weather', 'sunny', 'rain', 'cold', 'hot', 'beautiful day'],
      responses: [
        "The weather can really affect our mood, can't it? I hope you're able to enjoy some fresh air today, even if it's just by an open window.",
        "It's nice to appreciate the weather! Whether it's sunny or rainy, each day brings its own beauty. How do you like to spend time outdoors?",
        "Weather watching can be so peaceful. Do you have a favorite type of weather or season?"
      ],
      mood: 'informative' as const
    }
  ];

  const getAIResponse = (userMessage: string): { text: string; mood: Message['mood'] } => {
    const lowerMessage = userMessage.toLowerCase();
    
    for (const responseSet of aiResponses) {
      if (responseSet.triggers.some(trigger => lowerMessage.includes(trigger))) {
        const randomResponse = responseSet.responses[Math.floor(Math.random() * responseSet.responses.length)];
        return { text: randomResponse, mood: responseSet.mood };
      }
    }
    
    // Default responses
    const defaultResponses = [
      { text: "That's interesting! Tell me more about that.", mood: 'informative' as const },
      { text: "I appreciate you sharing that with me. How does that make you feel?", mood: 'caring' as const },
      { text: "Thank you for telling me about that. I'm here to listen and chat whenever you need.", mood: 'caring' as const },
      { text: "I find our conversations so meaningful. What else is on your mind today?", mood: 'encouraging' as const }
    ];
    
    return defaultResponses[Math.floor(Math.random() * defaultResponses.length)];
  };

  const handleSendMessage = async () => {
    if (inputText.trim() === '') return;

    const userMessage: Message = {
      id: Date.now().toString() + '-user',
      text: inputText,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsTyping(true);

    // Simulate AI thinking time
    setTimeout(() => {
      const aiResponse = getAIResponse(inputText);
      const aiMessage: Message = {
        id: Date.now().toString() + '-ai',
        text: aiResponse.text,
        sender: 'ai',
        timestamp: new Date(),
        mood: aiResponse.mood
      };
      
      setMessages(prev => [...prev, aiMessage]);
      setIsTyping(false);
    }, 1500);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const getMoodColor = (mood?: Message['mood']) => {
    switch (mood) {
      case 'happy':
        return 'bg-yellow-50 border-yellow-200';
      case 'caring':
        return 'bg-pink-50 border-pink-200';
      case 'encouraging':
        return 'bg-green-50 border-green-200';
      case 'informative':
        return 'bg-blue-50 border-blue-200';
      default:
        return 'bg-gray-50 border-gray-200';
    }
  };

  const getMoodIcon = (mood?: Message['mood']) => {
    switch (mood) {
      case 'happy':
        return <Smile className="h-4 w-4 text-yellow-600" />;
      case 'caring':
        return <Heart className="h-4 w-4 text-pink-600" />;
      case 'encouraging':
        return <Heart className="h-4 w-4 text-green-600" />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex flex-col">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={onBack}
                className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <ArrowLeft className="h-6 w-6" />
              </button>
              <div className="flex items-center space-x-3">
                <div className="bg-blue-600 p-2 rounded-full">
                  <MessageCircle className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-gray-900">Echo</h1>
                  <p className="text-sm text-gray-600">Your AI Companion</p>
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <div className="bg-green-100 px-3 py-1 rounded-full">
                <span className="text-sm font-medium text-green-800">Online</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Chat Messages */}
      <div className="flex-1 max-w-4xl mx-auto w-full px-6 py-6 overflow-y-auto">
        <div className="space-y-6">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-md rounded-2xl px-6 py-4 ${
                  message.sender === 'user'
                    ? 'bg-blue-600 text-white'
                    : `${getMoodColor(message.mood)} border-2`
                }`}
              >
                {message.sender === 'ai' && (
                  <div className="flex items-center space-x-2 mb-2">
                    <span className="text-sm font-medium text-gray-600">Echo</span>
                    {getMoodIcon(message.mood)}
                  </div>
                )}
                <p className={`text-lg leading-relaxed ${
                  message.sender === 'user' ? 'text-white' : 'text-gray-800'
                }`}>
                  {message.text}
                </p>
                <p className={`text-sm mt-2 ${
                  message.sender === 'user' ? 'text-blue-100' : 'text-gray-500'
                }`}>
                  {message.timestamp.toLocaleTimeString('en-US', { 
                    hour: 'numeric', 
                    minute: '2-digit',
                    hour12: true
                  })}
                </p>
              </div>
            </div>
          ))}
          
          {isTyping && (
            <div className="flex justify-start">
              <div className="bg-gray-100 border-2 border-gray-200 rounded-2xl px-6 py-4 max-w-md">
                <div className="flex items-center space-x-2 mb-2">
                  <span className="text-sm font-medium text-gray-600">Echo</span>
                </div>
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
                </div>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Input Area */}
      <div className="bg-white border-t border-gray-200 px-6 py-4">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-end space-x-4">
            <button className="p-3 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded-full transition-colors">
              <Mic className="h-6 w-6" />
            </button>
            
            <div className="flex-1 relative">
              <textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Type your message here..."
                className="w-full px-4 py-3 pr-12 text-lg border-2 border-gray-300 rounded-2xl focus:border-blue-500 focus:outline-none resize-none"
                rows={1}
                style={{ minHeight: '52px', maxHeight: '120px' }}
              />
              <button
                onClick={handleSendMessage}
                disabled={inputText.trim() === ''}
                className="absolute right-3 bottom-3 p-2 bg-blue-600 text-white rounded-full hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
              >
                <Send className="h-5 w-5" />
              </button>
            </div>
            
            <button className="p-3 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded-full transition-colors">
              <Volume2 className="h-6 w-6" />
            </button>
          </div>
          
          <div className="mt-3 flex justify-center space-x-4">
            <button
              onClick={() => setInputText("How are you today?")}
              className="px-4 py-2 text-sm bg-gray-100 text-gray-700 rounded-full hover:bg-gray-200 transition-colors"
            >
              How are you today?
            </button>
            <button
              onClick={() => setInputText("Tell me something interesting")}
              className="px-4 py-2 text-sm bg-gray-100 text-gray-700 rounded-full hover:bg-gray-200 transition-colors"
            >
              Tell me something interesting
            </button>
            <button
              onClick={() => setInputText("I need some encouragement")}
              className="px-4 py-2 text-sm bg-gray-100 text-gray-700 rounded-full hover:bg-gray-200 transition-colors"
            >
              I need encouragement
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AICompanion;