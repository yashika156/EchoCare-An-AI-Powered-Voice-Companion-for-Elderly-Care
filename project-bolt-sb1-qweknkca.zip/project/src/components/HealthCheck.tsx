import React, { useState } from 'react';
import { Heart, Activity, Moon, Smile, ArrowLeft, Calendar, TrendingUp } from 'lucide-react';

interface HealthMetrics {
  mood: number;
  energy: number;
  sleep: number;
  pain: number;
  appetite: number;
}

interface HealthCheckProps {
  onBack: () => void;
}

const HealthCheck: React.FC<HealthCheckProps> = ({ onBack }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [metrics, setMetrics] = useState<HealthMetrics>({
    mood: 0,
    energy: 0,
    sleep: 0,
    pain: 0,
    appetite: 0
  });
  
  const [notes, setNotes] = useState('');
  const [isComplete, setIsComplete] = useState(false);

  const questions = [
    {
      title: "How is your mood today?",
      subtitle: "Rate how you're feeling emotionally",
      key: 'mood' as keyof HealthMetrics,
      icon: <Smile className="h-8 w-8" />,
      color: 'from-yellow-500 to-orange-500',
      labels: ['Very Low', 'Low', 'Okay', 'Good', 'Excellent']
    },
    {
      title: "How is your energy level?",
      subtitle: "Rate your physical energy today",
      key: 'energy' as keyof HealthMetrics,
      icon: <Activity className="h-8 w-8" />,
      color: 'from-green-500 to-emerald-500',
      labels: ['Very Tired', 'Tired', 'Moderate', 'Energetic', 'Very Energetic']
    },
    {
      title: "How well did you sleep?",
      subtitle: "Rate the quality of your sleep last night",
      key: 'sleep' as keyof HealthMetrics,
      icon: <Moon className="h-8 w-8" />,
      color: 'from-blue-500 to-indigo-500',
      labels: ['Very Poor', 'Poor', 'Fair', 'Good', 'Excellent']
    },
    {
      title: "Any pain or discomfort?",
      subtitle: "Rate any physical discomfort you're experiencing",
      key: 'pain' as keyof HealthMetrics,
      icon: <Heart className="h-8 w-8" />,
      color: 'from-red-500 to-pink-500',
      labels: ['Severe', 'Moderate', 'Mild', 'Very Little', 'None'],
      reverse: true
    },
    {
      title: "How is your appetite?",
      subtitle: "Rate your interest in eating today",
      key: 'appetite' as keyof HealthMetrics,
      icon: <Activity className="h-8 w-8" />,
      color: 'from-purple-500 to-violet-500',
      labels: ['Very Poor', 'Poor', 'Fair', 'Good', 'Excellent']
    }
  ];

  const handleRating = (value: number) => {
    const currentQuestion = questions[currentStep];
    const actualValue = currentQuestion.reverse ? 6 - value : value;
    
    setMetrics(prev => ({
      ...prev,
      [currentQuestion.key]: actualValue
    }));
  };

  const handleNext = () => {
    if (currentStep < questions.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      // Show notes step
      setCurrentStep(questions.length);
    }
  };

  const handleComplete = () => {
    setIsComplete(true);
    // Here you would typically save the data
    console.log('Health check completed:', { metrics, notes });
  };

  const getOverallScore = () => {
    const total = Object.values(metrics).reduce((sum, value) => sum + value, 0);
    return Math.round((total / (questions.length * 5)) * 100);
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getScoreMessage = (score: number) => {
    if (score >= 80) return "You're doing great today! Keep up the good work.";
    if (score >= 60) return "You're doing okay. Remember to take care of yourself.";
    return "It seems like you might benefit from some extra self-care today.";
  };

  if (isComplete) {
    const score = getOverallScore();
    
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100">
        <div className="bg-white shadow-sm border-b border-gray-200">
          <div className="max-w-4xl mx-auto px-6 py-4">
            <div className="flex items-center space-x-4">
              <button
                onClick={onBack}
                className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <ArrowLeft className="h-6 w-6" />
              </button>
              <div className="flex items-center space-x-3">
                <div className="bg-green-600 p-2 rounded-lg">
                  <Heart className="h-6 w-6 text-white" />
                </div>
                <h1 className="text-2xl font-bold text-gray-900">Health Check Complete</h1>
              </div>
            </div>
          </div>
        </div>

        <div className="max-w-4xl mx-auto px-6 py-8">
          <div className="bg-white rounded-2xl shadow-lg p-8 text-center">
            <div className="mb-6">
              <div className={`text-6xl font-bold ${getScoreColor(score)} mb-2`}>
                {score}%
              </div>
              <p className="text-xl text-gray-600">Overall Wellness Score</p>
            </div>
            
            <div className="mb-8">
              <p className="text-lg text-gray-800 mb-4">{getScoreMessage(score)}</p>
              <div className="flex justify-center">
                <TrendingUp className={`h-12 w-12 ${getScoreColor(score)}`} />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <div className="bg-yellow-50 rounded-lg p-4">
                <h3 className="font-semibold text-yellow-900 mb-2">Mood</h3>
                <div className="flex space-x-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <div
                      key={star}
                      className={`w-4 h-4 rounded-full ${
                        star <= metrics.mood ? 'bg-yellow-400' : 'bg-gray-200'
                      }`}
                    />
                  ))}
                </div>
              </div>
              
              <div className="bg-green-50 rounded-lg p-4">
                <h3 className="font-semibold text-green-900 mb-2">Energy</h3>
                <div className="flex space-x-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <div
                      key={star}
                      className={`w-4 h-4 rounded-full ${
                        star <= metrics.energy ? 'bg-green-400' : 'bg-gray-200'
                      }`}
                    />
                  ))}
                </div>
              </div>
              
              <div className="bg-blue-50 rounded-lg p-4">
                <h3 className="font-semibold text-blue-900 mb-2">Sleep</h3>
                <div className="flex space-x-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <div
                      key={star}
                      className={`w-4 h-4 rounded-full ${
                        star <= metrics.sleep ? 'bg-blue-400' : 'bg-gray-200'
                      }`}
                    />
                  ))}
                </div>
              </div>
              
              <div className="bg-purple-50 rounded-lg p-4">
                <h3 className="font-semibold text-purple-900 mb-2">Comfort</h3>
                <div className="flex space-x-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <div
                      key={star}
                      className={`w-4 h-4 rounded-full ${
                        star <= metrics.pain ? 'bg-purple-400' : 'bg-gray-200'
                      }`}
                    />
                  ))}
                </div>
              </div>
            </div>

            {notes && (
              <div className="bg-gray-50 rounded-lg p-4 mb-6">
                <h3 className="font-semibold text-gray-900 mb-2">Your Notes</h3>
                <p className="text-gray-700">{notes}</p>
              </div>
            )}

            <div className="text-sm text-gray-500">
              <Calendar className="h-4 w-4 inline mr-1" />
              Completed on {new Date().toLocaleDateString('en-US', { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric',
                hour: 'numeric',
                minute: '2-digit'
              })}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Notes step
  if (currentStep === questions.length) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="bg-white shadow-sm border-b border-gray-200">
          <div className="max-w-4xl mx-auto px-6 py-4">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => setCurrentStep(currentStep - 1)}
                className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <ArrowLeft className="h-6 w-6" />
              </button>
              <div className="flex items-center space-x-3">
                <div className="bg-blue-600 p-2 rounded-lg">
                  <Heart className="h-6 w-6 text-white" />
                </div>
                <h1 className="text-2xl font-bold text-gray-900">Additional Notes</h1>
              </div>
            </div>
          </div>
        </div>

        <div className="max-w-4xl mx-auto px-6 py-8">
          <div className="bg-white rounded-2xl shadow-lg p-8">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">
                Any additional notes or concerns?
              </h2>
              <p className="text-gray-600">
                Share anything else about how you're feeling today (optional)
              </p>
            </div>

            <div className="mb-8">
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Feel free to share any thoughts, concerns, or observations about your health today..."
                className="w-full h-32 px-4 py-3 text-lg border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none resize-none"
              />
            </div>

            <div className="flex justify-center space-x-4">
              <button
                onClick={handleComplete}
                className="px-8 py-3 bg-blue-600 text-white text-lg font-semibold rounded-lg hover:bg-blue-700 transition-colors"
              >
                Complete Health Check
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Question steps
  const currentQuestion = questions[currentStep];
  const currentValue = metrics[currentQuestion.key];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={currentStep === 0 ? onBack : () => setCurrentStep(currentStep - 1)}
                className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <ArrowLeft className="h-6 w-6" />
              </button>
              <div className="flex items-center space-x-3">
                <div className="bg-blue-600 p-2 rounded-lg">
                  <Heart className="h-6 w-6 text-white" />
                </div>
                <h1 className="text-2xl font-bold text-gray-900">Daily Health Check</h1>
              </div>
            </div>
            <div className="text-sm text-gray-600">
              {currentStep + 1} of {questions.length}
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6 py-8">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="bg-gray-200 rounded-full h-2">
            <div
              className="bg-blue-600 h-2 rounded-full transition-all duration-300"
              style={{ width: `${((currentStep + 1) / questions.length) * 100}%` }}
            />
          </div>
        </div>

        {/* Question Card */}
        <div className="bg-white rounded-2xl shadow-lg p-8">
          <div className="text-center mb-8">
            <div className={`bg-gradient-to-r ${currentQuestion.color} p-4 rounded-full inline-block text-white mb-6`}>
              {currentQuestion.icon}
            </div>
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              {currentQuestion.title}
            </h2>
            <p className="text-lg text-gray-600">
              {currentQuestion.subtitle}
            </p>
          </div>

          {/* Rating Scale */}
          <div className="mb-8">
            <div className="flex justify-center space-x-4 mb-6">
              {[1, 2, 3, 4, 5].map((value) => (
                <button
                  key={value}
                  onClick={() => handleRating(value)}
                  className={`w-16 h-16 rounded-full border-2 transition-all duration-200 ${
                    currentValue === (currentQuestion.reverse ? 6 - value : value)
                      ? `bg-gradient-to-r ${currentQuestion.color} border-transparent text-white`
                      : 'border-gray-300 hover:border-gray-400 text-gray-600'
                  }`}
                >
                  <span className="text-xl font-bold">{value}</span>
                </button>
              ))}
            </div>
            
            <div className="flex justify-between text-sm text-gray-500 px-2">
              <span>{currentQuestion.labels[0]}</span>
              <span>{currentQuestion.labels[4]}</span>
            </div>
          </div>

          {/* Navigation */}
          <div className="flex justify-center space-x-4">
            <button
              onClick={handleNext}
              disabled={currentValue === 0}
              className="px-8 py-3 bg-blue-600 text-white text-lg font-semibold rounded-lg hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
            >
              {currentStep === questions.length - 1 ? 'Continue' : 'Next'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HealthCheck;