import React, { useState } from 'react';
import { Clock, Pill, Calendar, Plus, ArrowLeft, Edit3, Trash2, Bell } from 'lucide-react';

interface Reminder {
  id: string;
  title: string;
  type: 'medication' | 'activity';
  time: string;
  frequency: string;
  isActive: boolean;
  description?: string;
  color: string;
}

interface RemindersProps {
  onBack: () => void;
}

const Reminders: React.FC<RemindersProps> = ({ onBack }) => {
  const [reminders, setReminders] = useState<Reminder[]>([
    {
      id: '1',
      title: 'Morning Medication',
      type: 'medication',
      time: '8:00 AM',
      frequency: 'Daily',
      isActive: true,
      description: 'Lisinopril 10mg with breakfast',
      color: 'from-blue-500 to-blue-600'
    },
    {
      id: '2',
      title: 'Evening Medication',
      type: 'medication',
      time: '6:00 PM',
      frequency: 'Daily',
      isActive: true,
      description: 'Metformin 500mg with dinner',
      color: 'from-green-500 to-green-600'
    },
    {
      id: '3',
      title: 'Morning Walk',
      type: 'activity',
      time: '9:00 AM',
      frequency: 'Daily',
      isActive: true,
      description: '15-minute gentle walk around the garden',
      color: 'from-purple-500 to-purple-600'
    },
    {
      id: '4',
      title: 'Call Sarah',
      type: 'activity',
      time: '4:00 PM',
      frequency: 'Weekly (Sunday)',
      isActive: true,
      description: 'Weekly check-in with daughter',
      color: 'from-pink-500 to-pink-600'
    },
    {
      id: '5',
      title: 'Vitamin D',
      type: 'medication',
      time: '12:00 PM',
      frequency: 'Daily',
      isActive: false,
      description: '1000 IU with lunch',
      color: 'from-orange-500 to-orange-600'
    }
  ]);

  const [showAddForm, setShowAddForm] = useState(false);
  const [editingReminder, setEditingReminder] = useState<Reminder | null>(null);

  const toggleReminder = (id: string) => {
    setReminders(prev => prev.map(reminder => 
      reminder.id === id ? { ...reminder, isActive: !reminder.isActive } : reminder
    ));
  };

  const deleteReminder = (id: string) => {
    setReminders(prev => prev.filter(reminder => reminder.id !== id));
  };

  const activeReminders = reminders.filter(r => r.isActive);
  const inactiveReminders = reminders.filter(r => !r.isActive);
  const medicationReminders = activeReminders.filter(r => r.type === 'medication');
  const activityReminders = activeReminders.filter(r => r.type === 'activity');

  const getTypeIcon = (type: string) => {
    return type === 'medication' ? <Pill className="h-6 w-6" /> : <Calendar className="h-6 w-6" />;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-100">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={onBack}
                className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <ArrowLeft className="h-6 w-6" />
              </button>
              <div className="flex items-center space-x-3">
                <div className="bg-orange-600 p-2 rounded-lg">
                  <Clock className="h-6 w-6 text-white" />
                </div>
                <h1 className="text-2xl font-bold text-gray-900">Reminders</h1>
              </div>
            </div>
            <button
              onClick={() => setShowAddForm(true)}
              className="flex items-center space-x-2 px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors"
            >
              <Plus className="h-5 w-5" />
              <span>Add Reminder</span>
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-8">
        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-2xl shadow-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Active Reminders</h3>
              <Bell className="h-6 w-6 text-green-500" />
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-gray-900 mb-2">
                {activeReminders.length}
              </div>
              <p className="text-gray-600">Currently active</p>
            </div>
          </div>

          <div className="bg-white rounded-2xl shadow-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Medications</h3>
              <Pill className="h-6 w-6 text-blue-500" />
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600 mb-2">
                {medicationReminders.length}
              </div>
              <p className="text-gray-600">Daily medications</p>
            </div>
          </div>

          <div className="bg-white rounded-2xl shadow-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Activities</h3>
              <Calendar className="h-6 w-6 text-purple-500" />
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-600 mb-2">
                {activityReminders.length}
              </div>
              <p className="text-gray-600">Scheduled activities</p>
            </div>
          </div>
        </div>

        {/* Active Reminders */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Active Reminders</h2>
          <div className="space-y-4">
            {activeReminders.map((reminder) => (
              <div
                key={reminder.id}
                className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-xl transition-shadow"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className={`bg-gradient-to-r ${reminder.color} p-3 rounded-full text-white`}>
                      {getTypeIcon(reminder.type)}
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-gray-900">{reminder.title}</h3>
                      <p className="text-gray-600">{reminder.description}</p>
                      <div className="flex items-center space-x-4 mt-2">
                        <span className="text-lg font-semibold text-blue-600">{reminder.time}</span>
                        <span className="text-sm text-gray-500">{reminder.frequency}</span>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          reminder.type === 'medication' 
                            ? 'bg-blue-100 text-blue-800' 
                            : 'bg-purple-100 text-purple-800'
                        }`}>
                          {reminder.type}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => setEditingReminder(reminder)}
                      className="p-2 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                    >
                      <Edit3 className="h-5 w-5" />
                    </button>
                    <button
                      onClick={() => toggleReminder(reminder.id)}
                      className="p-2 text-gray-500 hover:text-orange-600 hover:bg-orange-50 rounded-lg transition-colors"
                    >
                      <Bell className="h-5 w-5" />
                    </button>
                    <button
                      onClick={() => deleteReminder(reminder.id)}
                      className="p-2 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                    >
                      <Trash2 className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Inactive Reminders */}
        {inactiveReminders.length > 0 && (
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Inactive Reminders</h2>
            <div className="space-y-4">
              {inactiveReminders.map((reminder) => (
                <div
                  key={reminder.id}
                  className="bg-gray-50 rounded-2xl shadow p-6 opacity-75"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="bg-gray-400 p-3 rounded-full text-white">
                        {getTypeIcon(reminder.type)}
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-gray-700">{reminder.title}</h3>
                        <p className="text-gray-500">{reminder.description}</p>
                        <div className="flex items-center space-x-4 mt-2">
                          <span className="text-lg font-semibold text-gray-500">{reminder.time}</span>
                          <span className="text-sm text-gray-400">{reminder.frequency}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => toggleReminder(reminder.id)}
                        className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                      >
                        Activate
                      </button>
                      <button
                        onClick={() => deleteReminder(reminder.id)}
                        className="p-2 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                      >
                        <Trash2 className="h-5 w-5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Today's Schedule */}
        <div className="mt-8 bg-white rounded-2xl shadow-lg p-6">
          <h3 className="text-xl font-bold text-gray-900 mb-4">Today's Schedule</h3>
          <div className="space-y-3">
            {activeReminders
              .sort((a, b) => {
                const timeA = new Date(`1970/01/01 ${a.time}`).getTime();
                const timeB = new Date(`1970/01/01 ${b.time}`).getTime();
                return timeA - timeB;
              })
              .map((reminder) => (
                <div key={reminder.id} className="flex items-center space-x-4 p-3 bg-gray-50 rounded-lg">
                  <div className="text-lg font-semibold text-gray-900 w-20">
                    {reminder.time}
                  </div>
                  <div className={`w-3 h-3 rounded-full bg-gradient-to-r ${reminder.color}`}></div>
                  <div>
                    <p className="font-medium text-gray-900">{reminder.title}</p>
                    <p className="text-sm text-gray-600">{reminder.description}</p>
                  </div>
                </div>
              ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Reminders;