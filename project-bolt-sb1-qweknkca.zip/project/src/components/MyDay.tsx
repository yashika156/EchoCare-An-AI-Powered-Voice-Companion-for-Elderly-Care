import React, { useState } from 'react';
import { Calendar, Activity, Heart, Clock, ArrowLeft, CheckCircle, Circle, TrendingUp } from 'lucide-react';

interface DayActivity {
  id: string;
  title: string;
  time: string;
  type: 'medication' | 'activity' | 'health' | 'social';
  completed: boolean;
  description?: string;
  color: string;
}

interface HealthMetric {
  name: string;
  value: number;
  max: number;
  color: string;
  icon: React.ReactNode;
}

interface MyDayProps {
  onBack: () => void;
}

const MyDay: React.FC<MyDayProps> = ({ onBack }) => {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [activities] = useState<DayActivity[]>([
    {
      id: '1',
      title: 'Morning Medication',
      time: '8:00 AM',
      type: 'medication',
      completed: true,
      description: 'Lisinopril 10mg taken with breakfast',
      color: 'from-blue-500 to-blue-600'
    },
    {
      id: '2',
      title: 'Morning Walk',
      time: '9:00 AM',
      type: 'activity',
      completed: true,
      description: '15-minute walk in the garden',
      color: 'from-green-500 to-green-600'
    },
    {
      id: '3',
      title: 'Health Check-in',
      time: '10:00 AM',
      type: 'health',
      completed: true,
      description: 'Daily wellness assessment completed',
      color: 'from-pink-500 to-pink-600'
    },
    {
      id: '4',
      title: 'Lunch & Vitamin D',
      time: '12:00 PM',
      type: 'medication',
      completed: false,
      description: '1000 IU Vitamin D with lunch',
      color: 'from-orange-500 to-orange-600'
    },
    {
      id: '5',
      title: 'Call Sarah',
      time: '4:00 PM',
      type: 'social',
      completed: false,
      description: 'Weekly check-in with daughter',
      color: 'from-purple-500 to-purple-600'
    },
    {
      id: '6',
      title: 'Evening Medication',
      time: '6:00 PM',
      type: 'medication',
      completed: false,
      description: 'Metformin 500mg with dinner',
      color: 'from-red-500 to-red-600'
    }
  ]);

  const [healthMetrics] = useState<HealthMetric[]>([
    {
      name: 'Mood',
      value: 4,
      max: 5,
      color: 'bg-yellow-500',
      icon: <Heart className="h-5 w-5" />
    },
    {
      name: 'Energy',
      value: 3,
      max: 5,
      color: 'bg-green-500',
      icon: <Activity className="h-5 w-5" />
    },
    {
      name: 'Sleep',
      value: 4,
      max: 5,
      color: 'bg-blue-500',
      icon: <Clock className="h-5 w-5" />
    }
  ]);

  const completedActivities = activities.filter(a => a.completed).length;
  const totalActivities = activities.length;
  const completionRate = Math.round((completedActivities / totalActivities) * 100);

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'medication':
        return '💊';
      case 'activity':
        return '🚶';
      case 'health':
        return '❤️';
      case 'social':
        return '📞';
      default:
        return '📅';
    }
  };

  const upcomingActivities = activities.filter(a => !a.completed);
  const completedToday = activities.filter(a => a.completed);

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-6 py-4">
          <div className="flex items-center space-x-4">
            <button
              onClick={onBack}
              className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <ArrowLeft className="h-6 w-6" />
            </button>
            <div className="flex items-center space-x-3">
              <div className="bg-green-600 p-2 rounded-lg">
                <Calendar className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">My Day</h1>
                <p className="text-sm text-gray-600">
                  {selectedDate.toLocaleDateString('en-US', { 
                    weekday: 'long', 
                    year: 'numeric', 
                    month: 'long', 
                    day: 'numeric' 
                  })}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-8">
        {/* Daily Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-2xl shadow-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Completion</h3>
              <TrendingUp className="h-6 w-6 text-green-500" />
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-green-600 mb-2">
                {completionRate}%
              </div>
              <p className="text-gray-600">{completedActivities} of {totalActivities} done</p>
              <div className="mt-3 bg-gray-200 rounded-full h-2">
                <div
                  className="bg-green-500 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${completionRate}%` }}
                />
              </div>
            </div>
          </div>

          {healthMetrics.map((metric) => (
            <div key={metric.name} className="bg-white rounded-2xl shadow-lg p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900">{metric.name}</h3>
                <div className={`p-2 rounded-full text-white ${metric.color}`}>
                  {metric.icon}
                </div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-gray-900 mb-2">
                  {metric.value}/{metric.max}
                </div>
                <div className="flex space-x-1 justify-center">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <div
                      key={star}
                      className={`w-3 h-3 rounded-full ${
                        star <= metric.value ? metric.color : 'bg-gray-200'
                      }`}
                    />
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Today's Timeline */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Completed Activities */}
          <div className="bg-white rounded-2xl shadow-lg p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-gray-900">Completed Today</h3>
              <CheckCircle className="h-6 w-6 text-green-500" />
            </div>
            
            <div className="space-y-4">
              {completedToday.map((activity) => (
                <div
                  key={activity.id}
                  className="flex items-center space-x-4 p-4 bg-green-50 rounded-lg border-l-4 border-green-500"
                >
                  <div className="text-2xl">{getTypeIcon(activity.type)}</div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <h4 className="font-semibold text-gray-900">{activity.title}</h4>
                      <span className="text-sm text-green-600 font-medium">{activity.time}</span>
                    </div>
                    <p className="text-sm text-gray-600 mt-1">{activity.description}</p>
                  </div>
                  <CheckCircle className="h-6 w-6 text-green-500" />
                </div>
              ))}
              
              {completedToday.length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  <Circle className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No activities completed yet today</p>
                </div>
              )}
            </div>
          </div>

          {/* Upcoming Activities */}
          <div className="bg-white rounded-2xl shadow-lg p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-gray-900">Coming Up</h3>
              <Clock className="h-6 w-6 text-blue-500" />
            </div>
            
            <div className="space-y-4">
              {upcomingActivities.map((activity) => (
                <div
                  key={activity.id}
                  className="flex items-center space-x-4 p-4 bg-blue-50 rounded-lg border-l-4 border-blue-500"
                >
                  <div className="text-2xl">{getTypeIcon(activity.type)}</div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <h4 className="font-semibold text-gray-900">{activity.title}</h4>
                      <span className="text-sm text-blue-600 font-medium">{activity.time}</span>
                    </div>
                    <p className="text-sm text-gray-600 mt-1">{activity.description}</p>
                  </div>
                  <Circle className="h-6 w-6 text-gray-400" />
                </div>
              ))}
              
              {upcomingActivities.length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  <CheckCircle className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>All activities completed for today!</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Weekly Overview */}
        <div className="mt-8 bg-white rounded-2xl shadow-lg p-6">
          <h3 className="text-xl font-bold text-gray-900 mb-6">This Week's Progress</h3>
          <div className="grid grid-cols-7 gap-4">
            {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day, index) => {
              const completion = Math.floor(Math.random() * 30) + 70; // Mock data
              const isToday = index === new Date().getDay() - 1;
              
              return (
                <div key={day} className={`text-center p-4 rounded-lg ${
                  isToday ? 'bg-blue-100 border-2 border-blue-500' : 'bg-gray-50'
                }`}>
                  <p className="text-sm font-medium text-gray-600 mb-2">{day}</p>
                  <div className={`w-16 h-16 rounded-full mx-auto flex items-center justify-center text-white font-bold text-lg ${
                    completion >= 90 ? 'bg-green-500' : 
                    completion >= 70 ? 'bg-yellow-500' : 'bg-red-500'
                  }`}>
                    {completion}%
                  </div>
                  <p className="text-xs text-gray-500 mt-2">
                    {completion >= 90 ? 'Excellent' : completion >= 70 ? 'Good' : 'Needs work'}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Daily Notes */}
        <div className="mt-8 bg-white rounded-2xl shadow-lg p-6">
          <h3 className="text-xl font-bold text-gray-900 mb-4">Today's Notes</h3>
          <div className="space-y-4">
            <div className="p-4 bg-yellow-50 rounded-lg border-l-4 border-yellow-500">
              <p className="text-sm text-yellow-800">
                <strong>10:30 AM:</strong> Feeling energetic after morning walk. Weather is perfect for outdoor activities.
              </p>
            </div>
            <div className="p-4 bg-blue-50 rounded-lg border-l-4 border-blue-500">
              <p className="text-sm text-blue-800">
                <strong>11:15 AM:</strong> Completed health check-in. Mood is good, energy level moderate. Slept well last night.
              </p>
            </div>
            <div className="p-4 bg-green-50 rounded-lg border-l-4 border-green-500">
              <p className="text-sm text-green-800">
                <strong>1:00 PM:</strong> Had a lovely lunch. Remember to take Vitamin D supplement.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MyDay;