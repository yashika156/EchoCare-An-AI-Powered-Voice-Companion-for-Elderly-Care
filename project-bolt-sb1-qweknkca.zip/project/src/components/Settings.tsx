import React, { useState } from 'react';
import { Settings as SettingsIcon, ArrowLeft, Volume2, VolumeX, User, Palette, Bell, Shield, HelpCircle } from 'lucide-react';

interface SettingsProps {
  onBack: () => void;
}

const Settings: React.FC<SettingsProps> = ({ onBack }) => {
  const [appName, setAppName] = useState('EchoCare');
  const [userName, setUserName] = useState('Margaret');
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [selectedVoice, setSelectedVoice] = useState('female-warm');
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [theme, setTheme] = useState('default');
  const [fontSize, setFontSize] = useState('large');

  const voiceOptions = [
    { id: 'female-warm', name: 'Sarah (Warm Female)', description: 'Gentle and caring voice' },
    { id: 'female-clear', name: 'Emma (Clear Female)', description: 'Clear and articulate' },
    { id: 'male-friendly', name: 'David (Friendly Male)', description: 'Warm and reassuring' },
    { id: 'male-professional', name: 'James (Professional Male)', description: 'Clear and professional' }
  ];

  const themeOptions = [
    { id: 'default', name: 'Default Blue', color: 'bg-blue-500' },
    { id: 'green', name: 'Calming Green', color: 'bg-green-500' },
    { id: 'purple', name: 'Gentle Purple', color: 'bg-purple-500' },
    { id: 'orange', name: 'Warm Orange', color: 'bg-orange-500' }
  ];

  const fontSizeOptions = [
    { id: 'medium', name: 'Medium', description: 'Standard size' },
    { id: 'large', name: 'Large', description: 'Easier to read' },
    { id: 'extra-large', name: 'Extra Large', description: 'Maximum readability' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-100">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-6 py-4">
          <div className="flex items-center space-x-4">
            <button
              onClick={onBack}
              className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <ArrowLeft className="h-6 w-6" />
            </button>
            <div className="flex items-center space-x-3">
              <div className="bg-gray-600 p-2 rounded-lg">
                <SettingsIcon className="h-6 w-6 text-white" />
              </div>
              <h1 className="text-2xl font-bold text-gray-900">Settings</h1>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6 py-8">
        {/* Personal Settings */}
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
          <div className="flex items-center space-x-3 mb-6">
            <User className="h-6 w-6 text-blue-600" />
            <h2 className="text-xl font-bold text-gray-900">Personal Settings</h2>
          </div>
          
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Your Name
              </label>
              <input
                type="text"
                value={userName}
                onChange={(e) => setUserName(e.target.value)}
                className="w-full px-4 py-3 text-lg border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none"
                placeholder="Enter your name"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                App Name
              </label>
              <input
                type="text"
                value={appName}
                onChange={(e) => setAppName(e.target.value)}
                className="w-full px-4 py-3 text-lg border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none"
                placeholder="Enter app name"
              />
            </div>
          </div>
        </div>

        {/* Voice Settings */}
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-3">
              <Volume2 className="h-6 w-6 text-green-600" />
              <h2 className="text-xl font-bold text-gray-900">Voice Settings</h2>
            </div>
            <button
              onClick={() => setVoiceEnabled(!voiceEnabled)}
              className={`p-3 rounded-lg transition-colors ${
                voiceEnabled 
                  ? 'bg-green-100 text-green-600 hover:bg-green-200' 
                  : 'bg-gray-100 text-gray-400 hover:bg-gray-200'
              }`}
            >
              {voiceEnabled ? <Volume2 className="h-6 w-6" /> : <VolumeX className="h-6 w-6" />}
            </button>
          </div>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <span className="text-lg font-medium text-gray-900">Enable Voice</span>
              <button
                onClick={() => setVoiceEnabled(!voiceEnabled)}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  voiceEnabled ? 'bg-green-600' : 'bg-gray-300'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    voiceEnabled ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>
            
            {voiceEnabled && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  Choose Voice
                </label>
                <div className="space-y-3">
                  {voiceOptions.map((voice) => (
                    <div
                      key={voice.id}
                      className={`p-4 rounded-lg border-2 cursor-pointer transition-colors ${
                        selectedVoice === voice.id
                          ? 'border-green-500 bg-green-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                      onClick={() => setSelectedVoice(voice.id)}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-semibold text-gray-900">{voice.name}</h4>
                          <p className="text-sm text-gray-600">{voice.description}</p>
                        </div>
                        <button className="px-3 py-1 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                          Test
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Appearance Settings */}
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
          <div className="flex items-center space-x-3 mb-6">
            <Palette className="h-6 w-6 text-purple-600" />
            <h2 className="text-xl font-bold text-gray-900">Appearance</h2>
          </div>
          
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Color Theme
              </label>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {themeOptions.map((themeOption) => (
                  <div
                    key={themeOption.id}
                    className={`p-4 rounded-lg border-2 cursor-pointer transition-colors ${
                      theme === themeOption.id
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                    onClick={() => setTheme(themeOption.id)}
                  >
                    <div className="flex items-center space-x-3">
                      <div className={`w-6 h-6 rounded-full ${themeOption.color}`}></div>
                      <span className="font-medium text-gray-900">{themeOption.name}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Text Size
              </label>
              <div className="space-y-3">
                {fontSizeOptions.map((size) => (
                  <div
                    key={size.id}
                    className={`p-4 rounded-lg border-2 cursor-pointer transition-colors ${
                      fontSize === size.id
                        ? 'border-purple-500 bg-purple-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                    onClick={() => setFontSize(size.id)}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-semibold text-gray-900">{size.name}</h4>
                        <p className="text-sm text-gray-600">{size.description}</p>
                      </div>
                      <span className={`font-bold ${
                        size.id === 'medium' ? 'text-base' :
                        size.id === 'large' ? 'text-lg' : 'text-xl'
                      }`}>
                        Sample Text
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Notification Settings */}
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
          <div className="flex items-center space-x-3 mb-6">
            <Bell className="h-6 w-6 text-orange-600" />
            <h2 className="text-xl font-bold text-gray-900">Notifications</h2>
          </div>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div>
                <h4 className="font-semibold text-gray-900">Enable Notifications</h4>
                <p className="text-sm text-gray-600">Receive reminders and alerts</p>
              </div>
              <button
                onClick={() => setNotificationsEnabled(!notificationsEnabled)}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  notificationsEnabled ? 'bg-orange-600' : 'bg-gray-300'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    notificationsEnabled ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>
            
            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div>
                <h4 className="font-semibold text-gray-900">Medication Reminders</h4>
                <p className="text-sm text-gray-600">Get notified when it's time for medication</p>
              </div>
              <button className="relative inline-flex h-6 w-11 items-center rounded-full bg-orange-600">
                <span className="inline-block h-4 w-4 transform rounded-full bg-white translate-x-6" />
              </button>
            </div>
            
            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div>
                <h4 className="font-semibold text-gray-900">Daily Check-ins</h4>
                <p className="text-sm text-gray-600">Reminder for daily health check-ins</p>
              </div>
              <button className="relative inline-flex h-6 w-11 items-center rounded-full bg-orange-600">
                <span className="inline-block h-4 w-4 transform rounded-full bg-white translate-x-6" />
              </button>
            </div>
          </div>
        </div>

        {/* Privacy & Security */}
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
          <div className="flex items-center space-x-3 mb-6">
            <Shield className="h-6 w-6 text-red-600" />
            <h2 className="text-xl font-bold text-gray-900">Privacy & Security</h2>
          </div>
          
          <div className="space-y-4">
            <button className="w-full p-4 text-left bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
              <h4 className="font-semibold text-gray-900">Data Privacy</h4>
              <p className="text-sm text-gray-600">Manage your data and privacy settings</p>
            </button>
            
            <button className="w-full p-4 text-left bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
              <h4 className="font-semibold text-gray-900">Emergency Access</h4>
              <p className="text-sm text-gray-600">Configure emergency contact permissions</p>
            </button>
            
            <button className="w-full p-4 text-left bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
              <h4 className="font-semibold text-gray-900">Backup & Sync</h4>
              <p className="text-sm text-gray-600">Backup your data and settings</p>
            </button>
          </div>
        </div>

        {/* Help & Support */}
        <div className="bg-white rounded-2xl shadow-lg p-6">
          <div className="flex items-center space-x-3 mb-6">
            <HelpCircle className="h-6 w-6 text-blue-600" />
            <h2 className="text-xl font-bold text-gray-900">Help & Support</h2>
          </div>
          
          <div className="space-y-4">
            <button className="w-full p-4 text-left bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
              <h4 className="font-semibold text-gray-900">User Guide</h4>
              <p className="text-sm text-gray-600">Learn how to use EchoCare</p>
            </button>
            
            <button className="w-full p-4 text-left bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
              <h4 className="font-semibold text-gray-900">Contact Support</h4>
              <p className="text-sm text-gray-600">Get help from our support team</p>
            </button>
            
            <button className="w-full p-4 text-left bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
              <h4 className="font-semibold text-gray-900">About EchoCare</h4>
              <p className="text-sm text-gray-600">Version 1.0.0 - Learn more about the app</p>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;