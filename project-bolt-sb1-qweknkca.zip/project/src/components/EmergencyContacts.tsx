import React from 'react';
import { Phone, Heart, Car, Shield, ArrowLeft } from 'lucide-react';

interface EmergencyContact {
  id: string;
  name: string;
  relationship: string;
  phone: string;
  type: 'family' | 'medical' | 'emergency';
  available: boolean;
}

interface EmergencyContactsProps {
  onBack: () => void;
}

const EmergencyContacts: React.FC<EmergencyContactsProps> = ({ onBack }) => {
  const contacts: EmergencyContact[] = [
    {
      id: '1',
      name: '911 Emergency',
      relationship: 'Emergency Services',
      phone: '911',
      type: 'emergency',
      available: true
    },
    {
      id: '2',
      name: 'Dr. Johnson',
      relationship: 'Primary Care',
      phone: '(555) 123-4567',
      type: 'medical',
      available: true
    },
    {
      id: '3',
      name: 'Sarah Mitchell',
      relationship: 'Daughter',
      phone: '(555) 234-5678',
      type: 'family',
      available: true
    },
    {
      id: '4',
      name: 'Michael Mitchell',
      relationship: 'Son',
      phone: '(555) 345-6789',
      type: 'family',
      available: false
    },
    {
      id: '5',
      name: 'Poison Control',
      relationship: 'Emergency Hotline',
      phone: '1-800-222-1222',
      type: 'emergency',
      available: true
    },
    {
      id: '6',
      name: 'Home Care Nurse',
      relationship: 'Healthcare',
      phone: '(555) 456-7890',
      type: 'medical',
      available: true
    }
  ];

  const getContactIcon = (type: string) => {
    switch (type) {
      case 'emergency':
        return <Shield className="h-6 w-6" />;
      case 'medical':
        return <Heart className="h-6 w-6" />;
      case 'family':
        return <Phone className="h-6 w-6" />;
      default:
        return <Phone className="h-6 w-6" />;
    }
  };

  const getContactColor = (type: string) => {
    switch (type) {
      case 'emergency':
        return 'from-red-500 to-red-600';
      case 'medical':
        return 'from-blue-500 to-blue-600';
      case 'family':
        return 'from-green-500 to-green-600';
      default:
        return 'from-gray-500 to-gray-600';
    }
  };

  const emergencyContacts = contacts.filter(c => c.type === 'emergency');
  const medicalContacts = contacts.filter(c => c.type === 'medical');
  const familyContacts = contacts.filter(c => c.type === 'family');

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-pink-100">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-6 py-4">
          <div className="flex items-center space-x-4">
            <button
              onClick={onBack}
              className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <ArrowLeft className="h-6 w-6" />
            </button>
            <div className="flex items-center space-x-3">
              <div className="bg-red-600 p-2 rounded-lg">
                <Phone className="h-6 w-6 text-white" />
              </div>
              <h1 className="text-2xl font-bold text-gray-900">Emergency Contacts</h1>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6 py-8">
        {/* Emergency Alert */}
        <div className="bg-red-100 border-l-4 border-red-500 p-6 mb-8 rounded-lg">
          <div className="flex items-center">
            <Shield className="h-8 w-8 text-red-500 mr-4" />
            <div>
              <h2 className="text-lg font-bold text-red-800">In Case of Emergency</h2>
              <p className="text-red-700">Call 911 immediately for life-threatening situations</p>
            </div>
          </div>
        </div>

        {/* Emergency Services */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Emergency Services</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {emergencyContacts.map((contact) => (
              <div
                key={contact.id}
                className={`bg-gradient-to-r ${getContactColor(contact.type)} rounded-2xl p-6 text-white cursor-pointer hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1`}
              >
                <div className="flex items-center justify-between mb-4">
                  {getContactIcon(contact.type)}
                  <div className="bg-white bg-opacity-20 px-3 py-1 rounded-full text-sm">
                    24/7
                  </div>
                </div>
                <h3 className="text-xl font-bold mb-1">{contact.name}</h3>
                <p className="text-sm opacity-90 mb-3">{contact.relationship}</p>
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-bold">{contact.phone}</span>
                  <Car className="h-6 w-6" />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Medical Contacts */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Medical Contacts</h2>
          <div className="space-y-4">
            {medicalContacts.map((contact) => (
              <div
                key={contact.id}
                className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-xl transition-shadow cursor-pointer"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className={`bg-gradient-to-r ${getContactColor(contact.type)} p-3 rounded-full text-white`}>
                      {getContactIcon(contact.type)}
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-gray-900">{contact.name}</h3>
                      <p className="text-gray-600">{contact.relationship}</p>
                      <p className="text-lg font-semibold text-blue-600">{contact.phone}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className={`px-3 py-1 rounded-full text-sm font-medium ${
                      contact.available
                        ? 'bg-green-100 text-green-800'
                        : 'bg-gray-100 text-gray-600'
                    }`}>
                      {contact.available ? 'Available' : 'Unavailable'}
                    </div>
                    <p className="text-sm text-gray-500 mt-1">Office Hours: 9-5</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Family Contacts */}
        <div>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Family Contacts</h2>
          <div className="space-y-4">
            {familyContacts.map((contact) => (
              <div
                key={contact.id}
                className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-xl transition-shadow cursor-pointer"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className={`bg-gradient-to-r ${getContactColor(contact.type)} p-3 rounded-full text-white`}>
                      {getContactIcon(contact.type)}
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-gray-900">{contact.name}</h3>
                      <p className="text-gray-600">{contact.relationship}</p>
                      <p className="text-lg font-semibold text-green-600">{contact.phone}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className={`px-3 py-1 rounded-full text-sm font-medium ${
                      contact.available
                        ? 'bg-green-100 text-green-800'
                        : 'bg-gray-100 text-gray-600'
                    }`}>
                      {contact.available ? 'Available' : 'Busy'}
                    </div>
                    <p className="text-sm text-gray-500 mt-1">
                      {contact.available ? 'Last seen: 2 hours ago' : 'In meeting'}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="mt-8 bg-white rounded-2xl shadow-lg p-6">
          <h3 className="text-xl font-bold text-gray-900 mb-4">Quick Actions</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <button className="p-4 bg-blue-50 rounded-lg text-left hover:bg-blue-100 transition-colors">
              <h4 className="font-semibold text-blue-900 mb-1">Send Location</h4>
              <p className="text-sm text-blue-700">Share your current location with family</p>
            </button>
            <button className="p-4 bg-green-50 rounded-lg text-left hover:bg-green-100 transition-colors">
              <h4 className="font-semibold text-green-900 mb-1">I'm Okay</h4>
              <p className="text-sm text-green-700">Send a quick status update to family</p>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmergencyContacts;