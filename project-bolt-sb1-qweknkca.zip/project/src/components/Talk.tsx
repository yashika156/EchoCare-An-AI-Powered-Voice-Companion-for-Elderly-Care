import React, { useState, useRef, useEffect } from 'react';
import { Mic, MicOff, Volume2, ArrowLeft, MessageCircle, Loader, Send, Key, VolumeX } from 'lucide-react';

interface TalkProps {
  onBack: () => void;
}

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'ai';
  timestamp: Date;
  isAudio?: boolean;
}

const Talk: React.FC<TalkProps> = ({ onBack }) => {
  const [isListening, setIsListening] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [userInput, setUserInput] = useState(''); // Store voice input
  const [textInput, setTextInput] = useState(''); // For manual text input
  const [apiKey, setApiKey] = useState('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'); // OpenAI API Key
  const [elevenLabsApiKey, setElevenLabsApiKey] = useState('sk_a4243ac01cb6bece17d66c8737163b1652994a917e8279ac'); // ElevenLabs API Key
  const [voiceId, setVoiceId] = useState('21m00Tcm4TlvDq8ikWAM'); // Default voice ID (Rachel)
  const [showApiKeyInput, setShowApiKeyInput] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [aiResponse, setAiResponse] = useState(''); // Store GPT-4 response
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: "Hello! I'm Echo, your AI companion. I'm here to chat, help with reminders, or just listen. You can talk to me using your voice or type a message. What would you like to talk about today?",
      sender: 'ai',
      timestamp: new Date(),
      isAudio: true
    }
  ]);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const currentAudioRef = useRef<HTMLAudioElement | null>(null);

  // Available ElevenLabs voices
  const availableVoices = [
    { id: '21m00Tcm4TlvDq8ikWAM', name: 'Rachel (Warm Female)', description: 'Calm and caring' },
    { id: 'AZnzlk1XvdvUeBnXmlld', name: 'Domi (Gentle Female)', description: 'Soft and nurturing' },
    { id: 'EXAVITQu4vr4xnSDxMaL', name: 'Bella (Clear Female)', description: 'Clear and articulate' },
    { id: 'ErXwobaYiN019PkySvjV', name: 'Antoni (Friendly Male)', description: 'Warm and reassuring' },
    { id: 'VR6AewLTigWG4xSOukaG', name: 'Arnold (Professional Male)', description: 'Clear and professional' }
  ];

  // Initialize Speech Recognition
  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      
      if (recognitionRef.current) {
        recognitionRef.current.continuous = false;
        recognitionRef.current.interimResults = true;
        recognitionRef.current.lang = 'en-US';

        recognitionRef.current.onstart = () => {
          setIsListening(true);
          setUserInput('');
        };

        recognitionRef.current.onresult = (event) => {
          let transcript = '';
          for (let i = event.resultIndex; i < event.results.length; i++) {
            transcript += event.results[i][0].transcript;
          }
          setUserInput(transcript);
        };

        recognitionRef.current.onend = () => {
          setIsListening(false);
          if (userInput.trim()) {
            handleUserMessage(userInput);
          }
        };

        recognitionRef.current.onerror = (event) => {
          console.error('Speech recognition error:', event.error);
          setIsListening(false);
          if (event.error === 'not-allowed') {
            alert('Please allow microphone access to use voice input.');
          }
        };
      }
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      if (currentAudioRef.current) {
        currentAudioRef.current.pause();
      }
    };
  }, [userInput]);

  // GPT-4 API Integration
  const sendToGPT4 = async (userSpeech: string): Promise<string> => {
    if (!apiKey.trim()) {
      return "Please set your OpenAI API key to use GPT-4. Click the key icon to add your API key.";
    }

    try {
      const response = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "gpt-4",
          messages: [
            {
              role: "system",
              content: "You are Echo, a caring AI companion for elderly users. You are warm, patient, and supportive. Keep responses conversational, encouraging, and helpful. Focus on their wellbeing, medication reminders, family connections, and daily activities. Be empathetic and understanding. Keep responses concise but meaningful."
            },
            {
              role: "user",
              content: userSpeech
            }
          ],
          max_tokens: 150,
          temperature: 0.7
        }),
      });

      if (!response.ok) {
        throw new Error(`API request failed: ${response.status}`);
      }

      const data = await response.json();
      const gptReply = data.choices[0].message.content;
      setAiResponse(gptReply); // Store GPT-4 response in aiResponse variable
      return gptReply;
    } catch (error) {
      console.error('GPT-4 API Error:', error);
      return "I'm having trouble connecting right now. Let me try to help you with a standard response. How are you feeling today?";
    }
  };

  // ElevenLabs Text-to-Speech Integration
  const convertToVoice = async (text: string): Promise<void> => {
    if (!voiceEnabled) {
      return;
    }

    // If no ElevenLabs API key, use browser speech synthesis
    if (!elevenLabsApiKey.trim()) {
      speakWithBrowserAPI(text);
      return;
    }

    try {
      setIsSpeaking(true);
      
      const voiceResponse = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`, {
        method: "POST",
        headers: {
          "xi-api-key": elevenLabsApiKey,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          text: text,
          model_id: "eleven_multilingual_v2", // Best model for natural tone
          voice_settings: {
            stability: 0.75,
            similarity_boost: 0.75,
            style: 0.2,
            use_speaker_boost: true
          }
        })
      });

      if (!voiceResponse.ok) {
        console.warn(`ElevenLabs API request failed: ${voiceResponse.status}. Falling back to browser speech synthesis.`);
        throw new Error(`ElevenLabs API request failed: ${voiceResponse.status}`);
      }

      const audioBlob = await voiceResponse.blob();
      const audioUrl = URL.createObjectURL(audioBlob);
      
      // Stop any currently playing audio
      if (currentAudioRef.current) {
        currentAudioRef.current.pause();
        currentAudioRef.current = null;
      }
      
      const audio = new Audio(audioUrl);
      currentAudioRef.current = audio;
      
      audio.onended = () => {
        setIsSpeaking(false);
        URL.revokeObjectURL(audioUrl); // Clean up memory
        currentAudioRef.current = null;
      };
      
      audio.onerror = () => {
        console.error('Audio playback error');
        setIsSpeaking(false);
        URL.revokeObjectURL(audioUrl);
        currentAudioRef.current = null;
        // Fallback to browser speech synthesis
        speakWithBrowserAPI(text);
      };
      
      await audio.play(); // This will speak it out
      
    } catch (error) {
      console.error('ElevenLabs TTS Error:', error);
      setIsSpeaking(false);
      // Fallback to browser speech synthesis
      speakWithBrowserAPI(text);
    }
  };

  // Fallback browser speech synthesis
  const speakWithBrowserAPI = (text: string) => {
    if (!voiceEnabled) return;
    
    setIsSpeaking(true);
    
    if ('speechSynthesis' in window) {
      // Stop any ongoing speech
      speechSynthesis.cancel();
      
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.8;
      utterance.pitch = 1;
      utterance.volume = 1;
      
      // Try to use a female voice
      const voices = speechSynthesis.getVoices();
      const femaleVoice = voices.find(voice => 
        voice.name.toLowerCase().includes('female') || 
        voice.name.toLowerCase().includes('woman') ||
        voice.name.toLowerCase().includes('samantha') ||
        voice.name.toLowerCase().includes('karen')
      );
      
      if (femaleVoice) {
        utterance.voice = femaleVoice;
      }
      
      utterance.onend = () => {
        setIsSpeaking(false);
      };
      
      utterance.onerror = () => {
        setIsSpeaking(false);
      };
      
      speechSynthesis.speak(utterance);
    } else {
      // Final fallback: simulate speech duration
      const duration = Math.max(2000, text.length * 50);
      setTimeout(() => {
        setIsSpeaking(false);
      }, duration);
    }
  };

  const stopSpeaking = () => {
    if (currentAudioRef.current) {
      currentAudioRef.current.pause();
      currentAudioRef.current = null;
    }
    if ('speechSynthesis' in window) {
      speechSynthesis.cancel();
    }
    setIsSpeaking(false);
  };

  const startListening = () => {
    if (recognitionRef.current && !isListening) {
      try {
        recognitionRef.current.start();
      } catch (error) {
        console.error('Error starting speech recognition:', error);
        simulateVoiceInput();
      }
    } else if (!recognitionRef.current) {
      simulateVoiceInput();
    }
  };

  const stopListening = () => {
    if (recognitionRef.current && isListening) {
      recognitionRef.current.stop();
    }
  };

  // Fallback simulation for demo purposes
  const simulateVoiceInput = () => {
    setIsListening(true);
    setUserInput('');
    
    const sampleResponses = [
      "How are you feeling today?",
      "Can you remind me to take my medicine at 6 PM?",
      "Tell me about the weather",
      "I'm feeling a bit lonely today",
      "What should I do this afternoon?",
      "Can you call my daughter Sarah?"
    ];
    
    const randomResponse = sampleResponses[Math.floor(Math.random() * sampleResponses.length)];
    
    let currentText = '';
    const words = randomResponse.split(' ');
    let wordIndex = 0;
    
    const addWord = () => {
      if (wordIndex < words.length) {
        currentText += (wordIndex > 0 ? ' ' : '') + words[wordIndex];
        setUserInput(currentText);
        wordIndex++;
        setTimeout(addWord, 300);
      } else {
        setTimeout(() => {
          setIsListening(false);
          handleUserMessage(currentText);
        }, 500);
      }
    };
    
    setTimeout(addWord, 500);
  };

  const handleUserMessage = async (text: string) => {
    if (!text.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString() + '-user',
      text: text.trim(),
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setUserInput('');
    setTextInput('');
    setIsProcessing(true);

    try {
      const gptResponse = await sendToGPT4(text.trim());
      
      const aiMessage: Message = {
        id: Date.now().toString() + '-ai',
        text: gptResponse,
        sender: 'ai',
        timestamp: new Date(),
        isAudio: true
      };
      
      setMessages(prev => [...prev, aiMessage]);
      setIsProcessing(false);
      
      // Convert GPT response to voice using ElevenLabs
      await convertToVoice(gptResponse);
      
    } catch (error) {
      console.error('Error processing message:', error);
      
      const fallbackMessage: Message = {
        id: Date.now().toString() + '-ai',
        text: "I'm having some technical difficulties right now, but I'm still here with you. How can I help you today?",
        sender: 'ai',
        timestamp: new Date(),
        isAudio: true
      };
      
      setMessages(prev => [...prev, fallbackMessage]);
      setIsProcessing(false);
    }
  };

  const handleTextSubmit = () => {
    if (textInput.trim()) {
      handleUserMessage(textInput);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleTextSubmit();
    }
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const isSpeechSupported = 'webkitSpeechRecognition' in window || 'SpeechRecognition' in window;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex flex-col">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={onBack}
                className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <ArrowLeft className="h-6 w-6" />
              </button>
              <div className="flex items-center space-x-3">
                <div className="bg-blue-600 p-2 rounded-full">
                  <MessageCircle className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-gray-900">Talk with Echo</h1>
                  <p className="text-sm text-gray-600">
                    {isListening ? 'Listening...' : isSpeaking ? 'Speaking...' : 'Ready to chat'}
                  </p>
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <button
                onClick={() => setVoiceEnabled(!voiceEnabled)}
                className={`p-2 rounded-lg transition-colors ${
                  voiceEnabled ? 'text-green-600 bg-green-50 hover:bg-green-100' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                }`}
                title={voiceEnabled ? 'Voice Enabled' : 'Voice Disabled'}
              >
                {voiceEnabled ? <Volume2 className="h-5 w-5" /> : <VolumeX className="h-5 w-5" />}
              </button>
              <button
                onClick={() => setShowApiKeyInput(!showApiKeyInput)}
                className={`p-2 rounded-lg transition-colors ${
                  (apiKey || elevenLabsApiKey) ? 'text-green-600 bg-green-50 hover:bg-green-100' : 'text-orange-600 bg-orange-50 hover:bg-orange-100'
                }`}
                title="API Settings"
              >
                <Key className="h-5 w-5" />
              </button>
              {isSpeaking && (
                <button
                  onClick={stopSpeaking}
                  className="p-2 text-red-600 bg-red-50 hover:bg-red-100 rounded-lg transition-colors"
                  title="Stop Speaking"
                >
                  <VolumeX className="h-5 w-5" />
                </button>
              )}
              <div className={`px-3 py-1 rounded-full text-sm font-medium ${
                isListening ? 'bg-red-100 text-red-800' : 
                isSpeaking ? 'bg-blue-100 text-blue-800' : 
                'bg-green-100 text-green-800'
              }`}>
                {isListening ? 'Listening' : isSpeaking ? 'Speaking' : 'Ready'}
              </div>
              {!isSpeechSupported && (
                <div className="px-3 py-1 rounded-full text-xs bg-yellow-100 text-yellow-800">
                  Demo Mode
                </div>
              )}
            </div>
          </div>
          
          {/* API Settings */}
          {showApiKeyInput && (
            <div className="mt-4 p-4 bg-gray-50 rounded-lg space-y-4">
              {apiKey.trim() ? (
                <div className="bg-green-50 border border-green-200 rounded-lg p-3 mb-4">
                  <p className="text-sm text-green-800">
                    <strong>✅ OpenAI API Key Connected!</strong> GPT-4 responses are now enabled.
                  </p>
                </div>
              ) : (
                <div className="bg-orange-50 border border-orange-200 rounded-lg p-3 mb-4">
                  <p className="text-sm text-orange-800">
                    <strong>⚠️ OpenAI API Key Required</strong> Please add your API key to enable GPT-4 responses.
                  </p>
                </div>
              )}
              
              {elevenLabsApiKey.trim() ? (
                <div className="bg-green-50 border border-green-200 rounded-lg p-3 mb-4">
                  <p className="text-sm text-green-800">
                    <strong>✅ ElevenLabs API Key Connected!</strong> Premium voice synthesis is enabled.
                  </p>
                </div>
              ) : (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-4">
                  <p className="text-sm text-blue-800">
                    <strong>ℹ️ ElevenLabs API Key Optional</strong> Using browser voice synthesis. Add ElevenLabs key for premium voices.
                  </p>
                </div>
              )}
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  OpenAI API Key (for GPT-4 responses)
                </label>
                <input
                  type="password"
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                  placeholder="sk-proj-..."
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                {apiKey.trim() ? (
                  <p className="text-xs text-green-600 mt-1">
                    ✅ Connected - GPT-4 responses enabled
                  </p>
                ) : (
                  <p className="text-xs text-gray-500 mt-1">
                    Get your API key from <a href="https://platform.openai.com/api-keys" target="_blank" rel="noopener noreferrer" className="underline">platform.openai.com</a>
                  </p>
                )}
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  ElevenLabs API Key (for premium voice synthesis)
                </label>
                <input
                  type="password"
                  value={elevenLabsApiKey}
                  onChange={(e) => setElevenLabsApiKey(e.target.value)}
                  placeholder="sk_..."
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                {elevenLabsApiKey.trim() ? (
                  <p className="text-xs text-green-600 mt-1">
                    ✅ Connected - Premium voice synthesis enabled
                  </p>
                ) : (
                  <p className="text-xs text-gray-500 mt-1">
                    Optional - Get your key from <a href="https://elevenlabs.io/app/speech-synthesis" target="_blank" rel="noopener noreferrer" className="underline">elevenlabs.io</a>
                  </p>
                )}
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Voice Selection (ElevenLabs only)
                </label>
                <select
                  value={voiceId}
                  onChange={(e) => setVoiceId(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  disabled={!elevenLabsApiKey.trim()}
                >
                  {availableVoices.map((voice) => (
                    <option key={voice.id} value={voice.id}>
                      {voice.name} - {voice.description}
                    </option>
                  ))}
                </select>
              </div>
              
              <div className="flex justify-end">
                <button
                  onClick={() => setShowApiKeyInput(false)}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Save Settings
                </button>
              </div>
              
              <p className="text-xs text-gray-500">
                Your API keys are stored locally in your browser and never sent to our servers
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Chat Messages */}
      <div className="flex-1 max-w-4xl mx-auto w-full px-6 py-6 overflow-y-auto">
        <div className="space-y-6">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-md rounded-2xl px-6 py-4 ${
                  message.sender === 'user'
                    ? 'bg-blue-600 text-white'
                    : 'bg-white border-2 border-gray-200 shadow-sm'
                }`}
              >
                {message.sender === 'ai' && (
                  <div className="flex items-center space-x-2 mb-2">
                    <span className="text-sm font-medium text-gray-600">Echo</span>
                    {message.isAudio && voiceEnabled && <Volume2 className="h-4 w-4 text-blue-500" />}
                    {apiKey && <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full">GPT-4</span>}
                    {elevenLabsApiKey && voiceEnabled && <span className="text-xs bg-purple-100 text-purple-800 px-2 py-1 rounded-full">ElevenLabs</span>}
                    {!elevenLabsApiKey && voiceEnabled && <span className="text-xs bg-gray-100 text-gray-800 px-2 py-1 rounded-full">Browser Voice</span>}
                  </div>
                )}
                <p className={`text-lg leading-relaxed ${
                  message.sender === 'user' ? 'text-white' : 'text-gray-800'
                }`}>
                  {message.text}
                </p>
                <p className={`text-sm mt-2 ${
                  message.sender === 'user' ? 'text-blue-100' : 'text-gray-500'
                }`}>
                  {message.timestamp.toLocaleTimeString('en-US', { 
                    hour: 'numeric', 
                    minute: '2-digit',
                    hour12: true
                  })}
                </p>
              </div>
            </div>
          ))}
          
          {isProcessing && (
            <div className="flex justify-start">
              <div className="bg-white border-2 border-gray-200 rounded-2xl px-6 py-4 max-w-md">
                <div className="flex items-center space-x-2 mb-2">
                  <span className="text-sm font-medium text-gray-600">Echo</span>
                  <Loader className="h-4 w-4 text-blue-500 animate-spin" />
                  {apiKey && <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">GPT-4</span>}
                </div>
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
                </div>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Input Area */}
      <div className="bg-white border-t border-gray-200 px-6 py-6">
        <div className="max-w-4xl mx-auto">
          {/* Current Voice Input Display */}
          {(isListening || userInput) && (
            <div className="mb-4 p-4 bg-blue-50 rounded-lg border-l-4 border-blue-500">
              <p className="text-sm text-blue-600 mb-1">
                {isListening ? 'Listening...' : 'You said:'}
              </p>
              <p className="text-lg text-gray-900">
                {userInput || (isListening ? 'Speak now...' : '')}
              </p>
            </div>
          )}

          {/* Voice Controls */}
          <div className="flex items-center justify-center space-x-6 mb-6">
            <button
              onClick={isListening ? stopListening : startListening}
              disabled={isProcessing || isSpeaking}
              className={`w-20 h-20 rounded-full flex items-center justify-center transition-all duration-300 transform hover:scale-105 ${
                isListening
                  ? 'bg-red-500 hover:bg-red-600 text-white animate-pulse'
                  : 'bg-blue-600 hover:bg-blue-700 text-white shadow-lg'
              } disabled:bg-gray-300 disabled:cursor-not-allowed`}
            >
              {isListening ? (
                <MicOff className="h-10 w-10" />
              ) : (
                <Mic className="h-10 w-10" />
              )}
            </button>
          </div>

          <div className="text-center mb-6">
            <p className="text-lg text-gray-600">
              {isListening ? 'Tap to stop listening' : 
               isProcessing ? 'Processing your message...' :
               isSpeaking ? 'Echo is speaking...' :
               'Tap the microphone to start talking'}
            </p>
            {!isSpeechSupported && (
              <p className="text-sm text-yellow-600 mt-2">
                Speech recognition not supported - using demo mode
              </p>
            )}
            {apiKey && (
              <p className="text-sm text-green-600 mt-2">
                ✅ GPT-4 connected and ready for intelligent responses
              </p>
            )}
            {!apiKey && (
              <p className="text-sm text-orange-600 mt-2">
                ⚠️ Please set your OpenAI API key to enable GPT-4 responses
              </p>
            )}
            {elevenLabsApiKey && voiceEnabled && (
              <p className="text-sm text-purple-600 mt-2">
                ✅ ElevenLabs premium voice synthesis enabled
              </p>
            )}
            {!elevenLabsApiKey && voiceEnabled && (
              <p className="text-sm text-blue-600 mt-2">
                Using browser voice synthesis (set ElevenLabs API key for premium voice)
              </p>
            )}
          </div>

          {/* Text Input Alternative */}
          <div className="mb-4">
            <div className="flex items-end space-x-4">
              <div className="flex-1 relative">
                <textarea
                  value={textInput}
                  onChange={(e) => setTextInput(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Or type your message here..."
                  className="w-full px-4 py-3 pr-12 text-lg border-2 border-gray-300 rounded-2xl focus:border-blue-500 focus:outline-none resize-none"
                  rows={1}
                  style={{ minHeight: '52px', maxHeight: '120px' }}
                  disabled={isListening || isProcessing || isSpeaking}
                />
                <button
                  onClick={handleTextSubmit}
                  disabled={textInput.trim() === '' || isListening || isProcessing || isSpeaking}
                  className="absolute right-3 bottom-3 p-2 bg-blue-600 text-white rounded-full hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
                >
                  <Send className="h-5 w-5" />
                </button>
              </div>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="flex justify-center space-x-4 flex-wrap gap-2">
            <button
              onClick={() => handleUserMessage("How are you today?")}
              disabled={isListening || isProcessing || isSpeaking}
              className="px-4 py-2 text-sm bg-gray-100 text-gray-700 rounded-full hover:bg-gray-200 transition-colors disabled:opacity-50"
            >
              How are you today?
            </button>
            <button
              onClick={() => handleUserMessage("What's the weather like?")}
              disabled={isListening || isProcessing || isSpeaking}
              className="px-4 py-2 text-sm bg-gray-100 text-gray-700 rounded-full hover:bg-gray-200 transition-colors disabled:opacity-50"
            >
              Weather update
            </button>
            <button
              onClick={() => handleUserMessage("Set a reminder")}
              disabled={isListening || isProcessing || isSpeaking}
              className="px-4 py-2 text-sm bg-gray-100 text-gray-700 rounded-full hover:bg-gray-200 transition-colors disabled:opacity-50"
            >
              Set reminder
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// Extend Window interface for TypeScript
declare global {
  interface Window {
    SpeechRecognition: any;
    webkitSpeechRecognition: any;
  }
}

export default Talk;