import React, { useState } from 'react';
import { Shield, Phone, Heart, Plus, ArrowLeft, Edit3, Trash2, MapPin, MessageSquare } from 'lucide-react';

interface EmergencyContact {
  id: string;
  name: string;
  relationship: string;
  phone: string;
  type: 'family' | 'medical' | 'emergency' | 'neighbor';
  isPrimary: boolean;
  available: boolean;
  notes?: string;
}

interface AlertsProps {
  onBack: () => void;
}

const Alerts: React.FC<AlertsProps> = ({ onBack }) => {
  const [contacts, setContacts] = useState<EmergencyContact[]>([
    {
      id: '1',
      name: '911 Emergency',
      relationship: 'Emergency Services',
      phone: '911',
      type: 'emergency',
      isPrimary: true,
      available: true,
      notes: 'For life-threatening emergencies only'
    },
    {
      id: '2',
      name: 'Sarah Mitchell',
      relationship: 'Daughter',
      phone: '(555) 234-5678',
      type: 'family',
      isPrimary: true,
      available: true,
      notes: 'Primary family contact - lives 10 minutes away'
    },
    {
      id: '3',
      name: 'Dr. Johnson',
      relationship: 'Primary Care Physician',
      phone: '(555) 123-4567',
      type: 'medical',
      isPrimary: true,
      available: true,
      notes: 'Office hours: Mon-Fri 9AM-5PM'
    },
    {
      id: '4',
      name: 'Michael Mitchell',
      relationship: 'Son',
      phone: '(555) 345-6789',
      type: 'family',
      isPrimary: false,
      available: false,
      notes: 'Lives out of state - backup contact'
    },
    {
      id: '5',
      name: 'Mary Thompson',
      relationship: 'Neighbor',
      phone: '(555) 456-7890',
      type: 'neighbor',
      isPrimary: false,
      available: true,
      notes: 'Next door neighbor - has spare key'
    },
    {
      id: '6',
      name: 'Poison Control',
      relationship: 'Emergency Hotline',
      phone: '1-800-222-1222',
      type: 'emergency',
      isPrimary: false,
      available: true,
      notes: '24/7 poison emergency assistance'
    }
  ]);

  const [showAddForm, setShowAddForm] = useState(false);
  const [editingContact, setEditingContact] = useState<EmergencyContact | null>(null);

  const getContactIcon = (type: string) => {
    switch (type) {
      case 'emergency':
        return <Shield className="h-6 w-6" />;
      case 'medical':
        return <Heart className="h-6 w-6" />;
      case 'family':
        return <Phone className="h-6 w-6" />;
      case 'neighbor':
        return <MapPin className="h-6 w-6" />;
      default:
        return <Phone className="h-6 w-6" />;
    }
  };

  const getContactColor = (type: string) => {
    switch (type) {
      case 'emergency':
        return 'from-red-500 to-red-600';
      case 'medical':
        return 'from-blue-500 to-blue-600';
      case 'family':
        return 'from-green-500 to-green-600';
      case 'neighbor':
        return 'from-purple-500 to-purple-600';
      default:
        return 'from-gray-500 to-gray-600';
    }
  };

  const primaryContacts = contacts.filter(c => c.isPrimary);
  const secondaryContacts = contacts.filter(c => !c.isPrimary);

  const deleteContact = (id: string) => {
    setContacts(prev => prev.filter(contact => contact.id !== id));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-pink-100">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={onBack}
                className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <ArrowLeft className="h-6 w-6" />
              </button>
              <div className="flex items-center space-x-3">
                <div className="bg-red-600 p-2 rounded-lg">
                  <Shield className="h-6 w-6 text-white" />
                </div>
                <h1 className="text-2xl font-bold text-gray-900">Emergency Alerts</h1>
              </div>
            </div>
            <button
              onClick={() => setShowAddForm(true)}
              className="flex items-center space-x-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
            >
              <Plus className="h-5 w-5" />
              <span>Add Contact</span>
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-8">
        {/* Emergency Alert Banner */}
        <div className="bg-red-100 border-l-4 border-red-500 p-6 mb-8 rounded-lg">
          <div className="flex items-center">
            <Shield className="h-8 w-8 text-red-500 mr-4" />
            <div>
              <h2 className="text-lg font-bold text-red-800">Emergency Protocol</h2>
              <p className="text-red-700">In case of emergency, call 911 first, then notify your primary contacts</p>
            </div>
          </div>
        </div>

        {/* Quick Emergency Actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <button className="bg-gradient-to-r from-red-500 to-red-600 rounded-2xl p-8 text-white text-left hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
            <div className="flex items-center justify-between mb-4">
              <Shield className="h-10 w-10" />
              <div className="bg-white bg-opacity-20 px-4 py-2 rounded-full text-sm">
                Emergency
              </div>
            </div>
            <h3 className="text-2xl font-bold mb-2">Call 911</h3>
            <p className="text-red-100 text-lg">Life-threatening emergency</p>
          </button>

          <button className="bg-gradient-to-r from-blue-500 to-blue-600 rounded-2xl p-8 text-white text-left hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
            <div className="flex items-center justify-between mb-4">
              <Heart className="h-10 w-10" />
              <div className="bg-white bg-opacity-20 px-4 py-2 rounded-full text-sm">
                Medical
              </div>
            </div>
            <h3 className="text-2xl font-bold mb-2">Call Doctor</h3>
            <p className="text-blue-100 text-lg">Non-emergency medical</p>
          </button>

          <button className="bg-gradient-to-r from-green-500 to-green-600 rounded-2xl p-8 text-white text-left hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
            <div className="flex items-center justify-between mb-4">
              <Phone className="h-10 w-10" />
              <div className="bg-white bg-opacity-20 px-4 py-2 rounded-full text-sm">
                Family
              </div>
            </div>
            <h3 className="text-2xl font-bold mb-2">Call Sarah</h3>
            <p className="text-green-100 text-lg">Primary family contact</p>
          </button>
        </div>

        {/* Primary Contacts */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Primary Contacts</h2>
          <div className="space-y-4">
            {primaryContacts.map((contact) => (
              <div
                key={contact.id}
                className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-xl transition-shadow"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className={`bg-gradient-to-r ${getContactColor(contact.type)} p-3 rounded-full text-white`}>
                      {getContactIcon(contact.type)}
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-gray-900">{contact.name}</h3>
                      <p className="text-gray-600">{contact.relationship}</p>
                      <p className="text-lg font-semibold text-blue-600">{contact.phone}</p>
                      {contact.notes && (
                        <p className="text-sm text-gray-500 mt-1">{contact.notes}</p>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="text-right">
                      <div className={`px-3 py-1 rounded-full text-sm font-medium ${
                        contact.available
                          ? 'bg-green-100 text-green-800'
                          : 'bg-gray-100 text-gray-600'
                      }`}>
                        {contact.available ? 'Available' : 'Unavailable'}
                      </div>
                      <div className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-xs font-medium mt-1">
                        Primary
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => setEditingContact(contact)}
                        className="p-2 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                      >
                        <Edit3 className="h-5 w-5" />
                      </button>
                      {contact.type !== 'emergency' && (
                        <button
                          onClick={() => deleteContact(contact.id)}
                          className="p-2 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        >
                          <Trash2 className="h-5 w-5" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Secondary Contacts */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Secondary Contacts</h2>
          <div className="space-y-4">
            {secondaryContacts.map((contact) => (
              <div
                key={contact.id}
                className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-xl transition-shadow"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className={`bg-gradient-to-r ${getContactColor(contact.type)} p-3 rounded-full text-white`}>
                      {getContactIcon(contact.type)}
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-gray-900">{contact.name}</h3>
                      <p className="text-gray-600">{contact.relationship}</p>
                      <p className="text-lg font-semibold text-blue-600">{contact.phone}</p>
                      {contact.notes && (
                        <p className="text-sm text-gray-500 mt-1">{contact.notes}</p>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="text-right">
                      <div className={`px-3 py-1 rounded-full text-sm font-medium ${
                        contact.available
                          ? 'bg-green-100 text-green-800'
                          : 'bg-gray-100 text-gray-600'
                      }`}>
                        {contact.available ? 'Available' : 'Unavailable'}
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => setEditingContact(contact)}
                        className="p-2 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                      >
                        <Edit3 className="h-5 w-5" />
                      </button>
                      {contact.type !== 'emergency' && (
                        <button
                          onClick={() => deleteContact(contact.id)}
                          className="p-2 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        >
                          <Trash2 className="h-5 w-5" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Emergency Features */}
        <div className="bg-white rounded-2xl shadow-lg p-6">
          <h3 className="text-xl font-bold text-gray-900 mb-6">Emergency Features</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-4 bg-blue-50 rounded-lg">
              <div className="flex items-center space-x-3 mb-3">
                <MapPin className="h-6 w-6 text-blue-600" />
                <h4 className="font-semibold text-blue-900">Location Sharing</h4>
              </div>
              <p className="text-sm text-blue-700 mb-3">
                Automatically share your location with emergency contacts when needed
              </p>
              <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                Enable Location
              </button>
            </div>

            <div className="p-4 bg-green-50 rounded-lg">
              <div className="flex items-center space-x-3 mb-3">
                <MessageSquare className="h-6 w-6 text-green-600" />
                <h4 className="font-semibold text-green-900">Quick Messages</h4>
              </div>
              <p className="text-sm text-green-700 mb-3">
                Send pre-written emergency messages to all contacts at once
              </p>
              <button className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
                Setup Messages
              </button>
            </div>

            <div className="p-4 bg-purple-50 rounded-lg">
              <div className="flex items-center space-x-3 mb-3">
                <Heart className="h-6 w-6 text-purple-600" />
                <h4 className="font-semibold text-purple-900">Medical Info</h4>
              </div>
              <p className="text-sm text-purple-700 mb-3">
                Store important medical information for emergency responders
              </p>
              <button className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
                Add Medical Info
              </button>
            </div>

            <div className="p-4 bg-orange-50 rounded-lg">
              <div className="flex items-center space-x-3 mb-3">
                <Shield className="h-6 w-6 text-orange-600" />
                <h4 className="font-semibold text-orange-900">Check-in Reminders</h4>
              </div>
              <p className="text-sm text-orange-700 mb-3">
                Set up regular check-ins with family members
              </p>
              <button className="px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors">
                Setup Check-ins
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Alerts;