import React from 'react';
import { MessageCircle, Heart, Clock, Calendar, Shield, Settings } from 'lucide-react';

interface HomeProps {
  onNavigate: (page: string) => void;
}

const Home: React.FC<HomeProps> = ({ onNavigate }) => {
  const currentTime = new Date();
  
  const getGreeting = () => {
    const hour = currentTime.getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    return 'Good evening';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="bg-blue-600 p-3 rounded-2xl">
                <Heart className="h-8 w-8 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-gray-900">EchoCare</h1>
                <p className="text-lg text-gray-600">Your AI Companion</p>
              </div>
            </div>
            <button
              onClick={() => onNavigate('settings')}
              className="p-3 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-xl transition-colors"
            >
              <Settings className="h-7 w-7" />
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6 py-8">
        {/* Welcome Section */}
        <div className="bg-white rounded-3xl shadow-lg p-8 mb-8 text-center">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            {getGreeting()}, Margaret!
          </h2>
          <p className="text-xl text-gray-600 mb-2">
            {currentTime.toLocaleDateString('en-US', { 
              weekday: 'long', 
              year: 'numeric', 
              month: 'long', 
              day: 'numeric' 
            })}
          </p>
          <p className="text-2xl font-semibold text-gray-800">
            {currentTime.toLocaleTimeString('en-US', { 
              hour: 'numeric', 
              minute: '2-digit',
              hour12: true 
            })}
          </p>
        </div>

        {/* Main Talk Button */}
        <div className="mb-8">
          <button
            onClick={() => onNavigate('talk')}
            className="w-full bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-3xl p-12 shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2"
          >
            <div className="flex flex-col items-center space-y-6">
              <div className="bg-white bg-opacity-20 p-6 rounded-full">
                <MessageCircle className="h-16 w-16" />
              </div>
              <div>
                <h3 className="text-3xl font-bold mb-2">Talk to Echo</h3>
                <p className="text-xl text-blue-100">Tap to start a conversation</p>
              </div>
            </div>
          </button>
        </div>

        {/* Quick Access Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <button
            onClick={() => onNavigate('reminders')}
            className="bg-gradient-to-br from-orange-500 to-orange-600 rounded-2xl p-8 text-white text-left hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1"
          >
            <div className="flex items-center justify-between mb-4">
              <Clock className="h-10 w-10" />
              <div className="bg-white bg-opacity-20 px-4 py-2 rounded-full text-sm">
                3 active
              </div>
            </div>
            <h3 className="text-2xl font-bold mb-2">Reminders</h3>
            <p className="text-orange-100 text-lg">Medications & activities</p>
          </button>

          <button
            onClick={() => onNavigate('myday')}
            className="bg-gradient-to-br from-green-500 to-green-600 rounded-2xl p-8 text-white text-left hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1"
          >
            <div className="flex items-center justify-between mb-4">
              <Calendar className="h-10 w-10" />
              <div className="bg-white bg-opacity-20 px-4 py-2 rounded-full text-sm">
                Today
              </div>
            </div>
            <h3 className="text-2xl font-bold mb-2">My Day</h3>
            <p className="text-green-100 text-lg">Daily summary & activities</p>
          </button>

          <button
            onClick={() => onNavigate('alerts')}
            className="bg-gradient-to-br from-red-500 to-red-600 rounded-2xl p-8 text-white text-left hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1"
          >
            <div className="flex items-center justify-between mb-4">
              <Shield className="h-10 w-10" />
              <div className="bg-white bg-opacity-20 px-4 py-2 rounded-full text-sm">
                Ready
              </div>
            </div>
            <h3 className="text-2xl font-bold mb-2">Alerts</h3>
            <p className="text-red-100 text-lg">Emergency contacts</p>
          </button>

          <div className="bg-white rounded-2xl p-8 shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <Heart className="h-10 w-10 text-pink-500" />
              <div className="bg-pink-100 px-4 py-2 rounded-full text-sm text-pink-800">
                Good
              </div>
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-2">Health Status</h3>
            <p className="text-gray-600 text-lg">Feeling well today</p>
          </div>
        </div>

        {/* Today's Highlights */}
        <div className="mt-8 bg-white rounded-2xl shadow-lg p-8">
          <h3 className="text-2xl font-bold text-gray-900 mb-6">Today's Highlights</h3>
          <div className="space-y-4">
            <div className="flex items-center space-x-4 p-4 bg-blue-50 rounded-xl">
              <div className="bg-blue-500 p-2 rounded-full">
                <Clock className="h-5 w-5 text-white" />
              </div>
              <div>
                <p className="font-semibold text-gray-900">Morning medication taken</p>
                <p className="text-gray-600">8:00 AM - Lisinopril completed</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4 p-4 bg-green-50 rounded-xl">
              <div className="bg-green-500 p-2 rounded-full">
                <Calendar className="h-5 w-5 text-white" />
              </div>
              <div>
                <p className="font-semibold text-gray-900">Doctor appointment reminder</p>
                <p className="text-gray-600">Tomorrow at 2:00 PM - Dr. Johnson</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4 p-4 bg-purple-50 rounded-xl">
              <div className="bg-purple-500 p-2 rounded-full">
                <Heart className="h-5 w-5 text-white" />
              </div>
              <div>
                <p className="font-semibold text-gray-900">Family call scheduled</p>
                <p className="text-gray-600">4:00 PM - Weekly chat with Sarah</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;