import React, { useState } from 'react';
import Home from './components/Home';
import Talk from './components/Talk';
import Reminders from './components/Reminders';
import MyDay from './components/MyDay';
import Alerts from './components/Alerts';
import Settings from './components/Settings';

type CurrentPage = 'home' | 'talk' | 'reminders' | 'myday' | 'alerts' | 'settings';

function App() {
  const [currentPage, setCurrentPage] = useState<CurrentPage>('home');

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'talk':
        return <Talk onBack={() => setCurrentPage('home')} />;
      case 'reminders':
        return <Reminders onBack={() => setCurrentPage('home')} />;
      case 'myday':
        return <MyDay onBack={() => setCurrentPage('home')} />;
      case 'alerts':
        return <Alerts onBack={() => setCurrentPage('home')} />;
      case 'settings':
        return <Settings onBack={() => setCurrentPage('home')} />;
      default:
        return <Home onNavigate={setCurrentPage} />;
    }
  };

  return (
    <div className="App">
      {renderCurrentPage()}
    </div>
  );
}

export default App;